# moonbit-ptp

`moonbit-ptp` is an experimental MoonBit prototype for selected IEEE 1588 Precision Time Protocol (PTP) concepts and an offline synchronization simulation. It is not a complete standards-interoperable PTP stack. Existing Mooncakes packages share some of its time, synchronization and simulation functionality; competition originality is not established.

## Four-layer minimum deliverable

1. **Protocol layer** — compact, bounded encode/decode for Sync, Follow_Up, Delay_Req, Delay_Resp and Announce messages, typed decode errors, plus a 34-octet IEEE 1588 common-header encoder.
2. **Clock layer** — ordinary-clock states, event-driven transitions, guarded Sync application and sequence monotonicity.
3. **BMCA layer** — deterministic comparison of priority1, clock class, accuracy, variance, priority2 and identity.
4. **Simulation layer** — offline network delay, jitter, loss, clock drift, PI servo control, correction clamping and a reproducible report.

The current release intentionally keeps OS clock access and UDP/Layer-2 transport outside the core. A future adapter can provide transport without changing the deterministic library or its tests. The current test suite has nine deterministic test cases and the CLI example is exercised by CI.

## Run

```sh
moon test
moon run cmd/main
```

The CLI prints the same result on every run:

```text
moonbit-ptp deterministic simulation
final_offset_ns=-212
maximum_offset_ns=8100
delivered=25 dropped=5
settled=true
```

The core does not read the host wall clock. It uses normalized `(seconds: Int64, nanos: Int32)` timestamps and integer octets so tests and simulation results are reproducible.

## Public API

The main types are `PtpMessage`, `PtpHeader`, `StandardHeader`, `Timestamp`, `Clock`, `ClockEvent`, `ClockQuality`, `SimulationConfig` and `SimulationReport`.

The main functions include:

- `timestamp` and `timestamp_parts`
- `source_port_identity` and `ptp_header`
- `sync_message`, `follow_up_message`, `delay_req_message` and `delay_resp_message`
- `encode`, `decode`, `standard_header` and `encode_standard_header`
- `select_grandmaster`, `Clock::on_event` and `simulate`

Public constructors are provided so external MoonBit packages can use the library without constructing private record fields.

## Current protocol boundary

The portable core includes a 34-octet IEEE 1588 common-header encoder with transport-specific bits, message type, version, message length, domain, flags, correction field, source identity, source port, sequence ID, control field and log interval. The compact message encoder remains available for deterministic unit-level examples.

Full message-specific standard-wire encoders/decoders, UDP/Layer-2 transport, hardware timestamps and LinuxPTP interoperability are deliberately outside this minimum release. The standard-header encoder validates that the source identity contains exactly eight octets.

## Scope and non-overlap statement

The 2026-10-19 audit snapshot contains 3,113 Mooncakes modules. Public root documentation was readable for 3,107 modules; six pages remained unavailable after retry. All 46 automatic-hit modules were reviewed, with a detailed functional comparison of 25 selected neighbors. Confirmed partial functional overlap exists with `xuting22/ntp` (time synchronization measurements and time-source selection), `Ljh684/moonnet-lab` and other deterministic simulation libraries (network delay/loss and reproducible simulation), and precision-time libraries (timestamp arithmetic). These are functional similarities, not evidence of copied source code. A different protocol name does not establish zero overlap.

Under the user's strict requirement that any similar or overlapping project is unacceptable, the current project cannot be marked safe to submit. The earlier 3,041-module keyword-based non-overlap conclusion is withdrawn. The audit report records full-index screening, public root-documentation coverage, reviewed neighbors and the limits of the conclusion.

See [docs/non-overlap.md](docs/non-overlap.md) for the evidence boundary and the exact comparison list.

## Charter compliance

The repository-level checklist is in [docs/charter-compliance.md](docs/charter-compliance.md). It separates requirements evidenced by code from requirements that require a real public repository, official application form, login-only charter details or final submission action.


## Redesign proposal (not implemented)

A fresh registry/documentation audit and a bounded review of 27 published source archives support further investigation of a PTP-specific two-step message-association and scoped BMCA-decision checker. This is a proposal, not a shipped feature or a guarantee of competition eligibility. See [the redesign plan](docs/redesign-plan.md) and [the fresh audit evidence](research/2026-10-19-redesign/review.md). The current code remains the prototype described above.
