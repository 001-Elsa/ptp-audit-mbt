# Two-clock example

The executable in `cmd/main` runs a deterministic master/slave-style simulation with:

- 30 steps
- 8,000 ns initial offset
- 20 ns drift per step
- 200 ns forward delay
- 220 ns reverse delay
- 30 ns jitter
- 5% deterministic packet loss
- proportional gain `kp = 45`
- integral gain `ki = 0`
- correction limit `max_adjustment = 10,000`

Run it with:

```sh
moon run cmd/main
```

Expected output from the current code:

```text
moonbit-ptp deterministic simulation
final_offset_ns=-212
maximum_offset_ns=8100
delivered=25 dropped=5
settled=true
```

The core simulation does not use the host wall clock or an unseeded random source, so the result is reproducible.
