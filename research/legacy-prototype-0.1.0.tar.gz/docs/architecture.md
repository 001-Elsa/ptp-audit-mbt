# Architecture and acceptance map

The implementation is kept in one dependency-free core package so all four layers share the same deterministic value types and can be published as one Mooncakes module.

| Layer | Current implementation | Acceptance evidence |
|---|---|---|
| Protocol | `PtpHeader`, `PtpMessage`, `Timestamp`, compact `encode`/`decode`, `DelayResp`, `StandardHeader`, `encode_standard_header` | Sync and Delay_Resp round-trips, invalid-version rejection, timestamp normalization, 34-octet header length and source-identity validation |
| Clock | `ClockState`, `Clock`, `ClockEvent`, `Clock::on_event`, sequence monotonicity and slave-only Sync application | stale-sync rejection and Initializing → Listening → Slave → timeout transition |
| BMCA | `ClockQuality`, `compare_quality`, `select_grandmaster` | lower `priority1` selection test |
| Simulation | `NetworkModel`, `ServoConfig`, PI control with `ki`, correction clamp with `max_adjustment`, `simulate` | deterministic convergence test and CLI report |

The timestamp model is normalized as `(seconds: Int64, nanos: Int32)`. The compact message format remains an explicitly bounded unit-test format. The standard-header encoder covers the 34-octet IEEE 1588 common header; message-specific standard-wire encoding and transport adapters are the next integration boundary.

## Improvements implemented

- Public constructors cover source identities, common headers, Sync, Follow_Up, Delay_Req, Delay_Resp, BMCA quality and simulation configuration.
- `Timestamp` stores normalized `Int64` seconds plus `Int32` nanoseconds and supports safe add/subtract/absolute-value operations.
- `StandardHeader` and `encode_standard_header` cover transport-specific bits, message type, version, message length, domain, flags, correction field, source identity, source port, sequence ID, control field and log interval.
- `ClockEvent` and `Clock::on_event` provide an event-driven ordinary-clock entry point with announce, sync, timeout, fault and reset events.
- The simulation uses proportional and integral terms and clamps correction to `max_adjustment`.
- The test suite contains nine deterministic assertions.
- A GitHub Actions workflow runs `moon info`, formatting checks, tests and the CLI example.
