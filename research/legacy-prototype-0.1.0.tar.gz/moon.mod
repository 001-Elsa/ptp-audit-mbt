// Learn more about moon.mod configuration:
// https://docs.moonbitlang.com/en/latest/toolchain/moon/module.html
//
// To add a dependency, run this command in your terminal:
//   moon add moonbitlang/x
//
// Or manually declare it in `import`, for example:
// import {
//   "moonbitlang/x@0.4.6",
// }

name = "moonbit-ptp/moonbit-ptp"

version = "0.1.0"

readme = "README.md"

repository = ""

license = "Apache-2.0"

keywords = [
  "ptp",
  "ieee1588",
  "clock-synchronization",
  "bmca",
  "moonbit",
  "network-simulation",
]

preferred_target = "wasm"

description = "Portable MoonBit IEEE 1588 PTP core with message modeling, BMCA, ordinary-clock events and deterministic synchronization simulation."
